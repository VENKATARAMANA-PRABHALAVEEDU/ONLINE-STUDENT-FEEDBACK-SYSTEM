<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="admin-home.php">Dashboard</a>
  <ul class="navbar-nav">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Faculty</a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="admin-add-faculty.php">Add Faculty</a>
            <a class="dropdown-item" href="admin-assign-faculty.php">Assign Faculty</a>
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Subjects</a>
        <div class="dropdown-menu">
            <a class="dropdown-item" href="admin-add-subject.php">Add Subject</a>
            <a class="dropdown-item" href="admin-assign-subject.php">Assign Subject</a>
        </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="admin-students.php">Students</a>
    </li> <li class="nav-item">
      <a class="nav-link" href="admin-view-feedback.php">View Feedback</a>
    </li>  
    <!--<li class="nav-item">
      <a class="nav-link" href="admin-departments.php">Departments</a>
    </li>-->
    <li class="nav-item">
      <a class="nav-link" href="javascript:void(0)" onclick="logout()">Logout</a>
    </li>
  </ul>
</nav>