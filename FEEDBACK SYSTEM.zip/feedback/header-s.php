<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="student-home.php">Dashboard</a>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="student-view-feedback.php">View Feedback</a>
    </li>   
    <li class="nav-item">
      <a class="nav-link" href="student-give-feedback.php">Give Feedback</a>
    </li> 
    <li class="nav-item">
      <a class="nav-link" href="student-change-password.php">Change Password</a>
    </li>
    <!--<li class="nav-item">
      <a class="nav-link" href="admin-departments.php">Departments</a>
    </li>-->
    <li class="nav-item">
      <a class="nav-link" href="javascript:void(0)" onclick="logout()">Logout</a>
    </li>
  </ul>
</nav>