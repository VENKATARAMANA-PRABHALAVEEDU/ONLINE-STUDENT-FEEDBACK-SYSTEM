<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Admin  asignfaculty</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
    var data=[];
    var data1=[];
    var data2=[];
    $(function(){
        getFaculty();
        getAssignedFaculty();
        getAssignedSubjects();
        getYearsBox('year');
        getYearsBox('year1');
        getSemestersBox('semester');
        getSemestersBox('semester1');
        getDepartmentsBox('department');
        getDepartmentsBox('department1');
        $("#regFm").on('submit',function(e){
            e.preventDefault();
            var stsID='msg1';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj={year:-1,semester:-1,department:-1,subject:-1,facultyID:-1};
            var status=0;
            for(var key in regObj)
            {
                var d=getValue(key);
                regObj[key]=d; 
                if(d==-1)
                {
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.getAttribute('placeholder')); 
                    break;
                }
            }
            if(status==0)
            {
                var fData=new FormData();
                
                for(var key in regObj)
                {
                    fData.append(key,regObj[key]);
                }
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=assignFaculty');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message);
                            getStudents();                          
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }

        });
    });
    function getAssignedFaculty()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getAssignedFaculty');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                if(result.status==1)
                {
                    data2=result.data;   
                    console.log(data2);                 
                }  
            }
        };  
    }
    function getStudents()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getStudents');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var x='<table class="table table-hover"><thead><tr><th>S.No</th><th>Year</th><th>Semester</th><th>Firstname</th><th>Lastname</th><th>Email</th></tr></thead><tbody>';
                var result=converToJson(http.responseText);
                console.log(result);
                if(result.status==1)
                {
                    data=result.data;
                    var sno=0;
                    for(var i=0;i<data.length;i++)
                    {
                        sno++;
                        x+='<tr><td>'+sno+'</td><td>'+data[i].YearName+' Year</td><td>'+data[i].SemesterName+' Semester</td><td>'+data[i].user_first_name+'</td><td>'+data[i].user_first_name+'</td><td>'+data[i].user_email+'</td></tr>';
                    }                      
                }                    
                x+='</tbody></table>';
                setData('faculty',x);
            }
        };  
    }
    function getSubjects()
    {
        console.log(data);
        var stsID='subject'; 
        var x='<option value="-1">Select Subject</option>';
            var regObj1={year:-1,semester:-1,department:-1};
            var status=0;
            for(var key in regObj1)
            {
                var d=getValue(key);
                regObj1[key]=d; 
                console.log(key);
                if(d==-1)
                {
                    console.log(d);
                    status=1;
                    var tag=getTag(key);
                    setData(stsID,x); 
                    break;
                }
            }
            if(status==0)
            {
                setData(stsID,x);
                var x='<option value="-1">Select Subject</option>';
                if(data1.length>0)
                {
                    var sno=0;
                    for(var i=0;i<data1.length;i++)
                    {
                        if(getValue('year')==data1[i].YearIDs && getValue('semester')==data1[i].SemesterIDs && getValue('department')==data1[i].dept_ids)
                        {
                            x+='<option value="'+data1[i].SubjectID+'">('+data1[i].SubjectCode+')'+data1[i].SubjectName+'</option>';
                        }                        
                    }                  
                }                 
                setData(stsID,x);
            }

    }
    function getAssignedSubjects()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getAssignedSubjects');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                if(result.status==1)
                {
                    data1=result.data;                    
                }  
            }
        };  
    }
    function getFaculty()
    {
        
        var http=new XMLHttpRequest();
            http.open('GET',apiURL+'?segment=getFaculty');
            http.send();
            http.onreadystatechange=function()
            {
                if(http.readyState==4 && http.status==200)
                {
                    var x='<option value="-1">Select Faculty</option>';
                    var result=converToJson(http.responseText);
                    if(result.status==1)
                    {
                        data=result.data;
                        var sno=0;
                        for(var i=0;i<data.length;i++)
                        {
                            x+='<option value="'+data[i].user_id+'">'+data[i].user_first_name+' '+data[i].user_last_name+'('+data[i].user_email+')</option>';
                        }                      
                    }                   
                    setData('facultyID',x);
                }
            };
        
    }
    function getFaculties()
    {
        console.log(data);
        var stsID='msg2';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj1={year1:-1,semester1:-1,department1:-1};
            var status=0;
            for(var key in regObj1)
            {
                var d=getValue(key);
                regObj1[key]=d; 
                console.log(key);
                if(d==-1)
                {
                    console.log(d);
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.getAttribute('placeholder')); 
                    break;
                }
            }
            if(status==0)
            {
                setData(stsID,'');
                var x='<table class="table table-hover"><thead><tr><th>S.No</th><th>Subject Code</th><th>Subject Name</th><th>Faculty Name</th><th>Faculty Email</th></tr></thead><tbody>';
                if(data2.length>0)
                {
                    var sno=0;
                    for(var i=0;i<data2.length;i++)
                    {
                        if(getValue('year1')==data2[i].YearIDs && getValue('semester1')==data2[i].SemesterIDs && getValue('department1')==data2[i].dept_ids)
                        {
                            sno++;
                            x+='<tr><td>'+sno+'</td><td>'+data2[i].SubjectCode+'</td><td>'+data2[i].SubjectName+'</td><td>'+data2[i].user_first_name+' '+data2[i].user_last_name+'</td><td>'+data2[i].user_email+'</td></tr>';
                        }
                        
                    }                      
                }                    
                x+='</tbody></table>';
                setData('faculty',x);
            }

    }
    </script>
</head>

<body>
<?php 
include('header-a.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Assign  <span>Faculty</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-12">
                       
                        <div class="row mb-2"> <div class="col-lg-2">
                        <a class="btn btn-primary mb-2" href="#myModal" data-toggle="modal">Assign Faculty</a>
                </div> <div class="col-lg-2">
                    <select id="year1" class="form-control" placeholder="Select Year"><option value="-1">Select Year</option></select>
                </div> 
                <div class="col-lg-2">
                    <select id="semester1" class="form-control" placeholder="Select Semester"><option value="-1">Select Semester</option></select>
                </div>
                        <div class="col-lg-3">
                            <select id="department1" class="form-control" placeholder="Select Department"><option value="-1">Select Department</option></select>
                            </div>
                            <div class="col-lg-2">
                            <button type="button" class="btn btn-success" onclick="getFaculties()">Get Faculty</button>
                            </div>
                            <div class="col-lg-12" id="msg2">
                            </div>
                        </div>
                        <div class="table-responsive" id="faculty"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>
     <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Assign Faculty</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" id="regFm">
                <div class="form-group">
                    <select id="year" class="form-control" placeholder="Select Year" onchange="getSubjects()"><option value="-1">Select Year</option></select>
                </div> 
                <div class="form-group">
                    <select id="semester" class="form-control" placeholder="Select Semester" onchange="getSubjects()"><option value="-1">Select Semester</option></select>
                </div>
                <div class="form-group">
                    <select id="department" class="form-control" placeholder="Select Department" onchange="getSubjects()"><option value="-1">Select Department</option></select>
                </div>
                <div class="form-group">
                    <select id="subject"  class="form-control" placeholder="Select Subject"><option value="-1">Select Subject</option></select>
                </div>
                <div class="form-group">
                    <select id="facultyID"  class="form-control" placeholder="Select Faculty"><option value="-1">Select Faculty</option></select>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Assign Faculty</button>
                </div>
                <div class="form-group text-center" id="msg1"></div>
          </form>
        </div> 
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
  
</body>
</html>