<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Admin Students</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
        var data=[];
    $(function(){
        getStudents();
        getYearsBox('year');
        getSemestersBox('semester');
        getDepartmentsBox('department');
        $("#regFm").on('submit',function(e){
            e.preventDefault();
            var stsID='msg1';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj={userPwd:'',userPwd1:''};
            var status=0;
            for(var key in regObj)
            {
                var d=getValue(key);
                regObj[key]=d; 
                if(d.trim().length==0)
                {
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.placeholder); 
                    break;
                }
            }
            if(status==0)
            {
                var fData=new FormData();
                
                for(var key in regObj)
                {
                    fData.append(key,regObj[key]);
                }
                fData.append('userID',loginObj.user_id);
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=changePassword');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message);  
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }

        });
    });
    function getStudents()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getStudents');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var x='<table class="table table-hover"><thead><tr><th>S.No</th><th>Year</th><th>Semester</th><th>Department</th><th>Firstname</th><th>Lastname</th><th>Email</th></tr></thead><tbody>';
                var result=converToJson(http.responseText);
                console.log(result);
                if(result.status==1)
                {
                    data=result.data;
                    var sno=0;
                    for(var i=0;i<data.length;i++)
                    {
                        sno++;
                        x+='<tr><td>'+sno+'</td><td>'+data[i].YearName+' Year</td><td>'+data[i].SemesterName+' Semester</td><td>'+data[i].dept_name+'</td><td>'+data[i].user_first_name+'</td><td>'+data[i].user_first_name+'</td><td>'+data[i].user_email+'</td></tr>';
                    }                      
                }                    
                x+='</tbody></table>';
                setData('faculty',x);
            }
        };  
    }
    </script>
</head>

<body>
<?php 
include('header-s.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Change  <span>Password</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-6 offset-md-3">
                    <form method="post" id="regFm">
                <div class="form-group">
                    <input type="password" id="userPwd" class="form-control" placeholder="Enter Password@" />
                </div>
                <div class="form-group">
                    <input type="password" id="userPwd1" class="form-control" placeholder="Enter Confirm Password" />
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Update Password</button>
                </div>
                <div class="form-group text-center" id="msg1"></div>
          </form>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>
 
</body>
</html>