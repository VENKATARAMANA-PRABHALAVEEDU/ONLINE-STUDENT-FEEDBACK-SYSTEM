<!DOCTYPE html>
<html lang="zxx">

<head>
    <title> Admin View feedback</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
        var data=[];
        var data2=[];
    $(function(){
        getAssignedFaculty();
    });
    function getAssignedFaculty()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getFaculty');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                var x='<option value="-1">Select subject</option>';
                if(result.status==1)
                {
                    data2=result.data;   
                    console.log(data2);
                    console.log(loginObj);  
                    for(var i=0;i<data2.length;i++)
                    {
                        x+='<option value="'+data2[i].user_id+'">'+data2[i].user_first_name+' '+data2[i].user_last_name+'('+data2[i].user_email+')</option>';
                       
                    }                
                }  
                setData('facultyIDs',x);
            }
        };  
    }
    function getGraph(id)
    { 
        if(id>0)
        {
            var http=new XMLHttpRequest();
            http.open('GET',apiURL+'?segment=showGraph&faculty='+id);
            http.send();
            http.onreadystatechange=function()
            {
                if(http.readyState==4 && http.status==200)
                {
                    var result=converToJson(http.responseText);
                    if(result.status==1)
                    {
                        data2=result.data;   
                        console.log(JSON.stringify(data2));
                        [].forEach.call(data2, function(inst, i){
                            // Iterate through all the keys
                            [].forEach.call(Object.keys(inst), function(y){
                                // Check if string is Numerical string
                                if(!isNaN(data2[i][y]))
                                    //Convert to numerical value
                                    data2[i][y] = +data2[i][y];
                            });
                            
                        });

                        console.log(data2);
                        var chart = new CanvasJS.Chart("chartContainer", {
                                theme: "theme2",
                                animationEnabled: true,
                                title: {
                                    text: "Faculty Feedback"
                                },
                                data: [
                                {
                                    type: "column",                
                                    dataPoints: data2
                                }
                                ]
                            });
                            chart.render();
                                       
                    }  
                }
            }; 
        }
        else 
        {
            var chart = new CanvasJS.Chart("chartContainer", {
                                theme: "theme2",
                                animationEnabled: true,
                                title: {
                                    text: "Faculty Feedback"
                                },
                                data: [
                                {
                                    type: "column",                
                                    dataPoints: ''
                                }
                                ]
                            });
                            chart.render();
        } 
    }
    </script>
    <script src="js/canvasjs.min.js"></script>
</head>

<body>
<?php 
include('header-a.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">View <span>Feedback</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-12">
                    <div class="row mb-2"> <div class="col-lg-6">
                    <select id="facultyIDs" class="form-control" placeholder="Select Faculty" onchange="getGraph(this.value)"><option value="-1">Select Faculty</option></select>
                </div> 
                            <div class="col-lg-12" id="msg2">
                            </div>
                        </div>
                        <div id="chartContainer"></div>
                    <?php

                        $dataPoints = array(
                            array("y" => 6, "label" => "Apple"),
                            array("y" => 4, "label" => "Mango"),
                            array("y" => 5, "label" => "Orange"),
                            array("y" => 9, "label" => "Banana"),
                            array("y" => 4, "label" => "Pineapple"),
                            array("y" => 6, "label" => "Pears"),
                            array("y" => 7, "label" => "Grapes"),
                            array("y" => 5, "label" => "Lychee"),
                            array("y" => 4, "label" => "Jackfruit")
                        );
                    ?>
                    <script type="text/javascript">
                        $(function () {
                           
                        });
                    </script>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>

</body>
</html>