<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Admin Students</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
        var data=[];
    $(function(){
        getAssignedSubjects();
        getYearsBox('year');
        getYearsBox('year1');
        getSemestersBox('semester');
        getSemestersBox('semester1');
        getDepartmentsBox('department');
        getDepartmentsBox('department1');
        getSubjectsBox('subject');
        $("#regFm").on('submit',function(e){
            e.preventDefault();
            var stsID='msg1';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj={year:-1,semester:-1,department:-1,subject:''};
            var status=0;
            for(var key in regObj)
            {
                var d=getValue(key);
                regObj[key]=d; 
                console.log(key);
                if(key=='subject')
                {
                    console.log(d);
                    if(d==null)
                    {
                        console.log(d);
                        status=1;
                        var tag=getTag(key);
                        showErrorMessage(stsID,tag.getAttribute('placeholder')); 
                        break;
                    }
                }
                if(d==-1)
                {
                    console.log(d);
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.getAttribute('placeholder')); 
                    break;
                }
            }
            if(status==0)
            {
                var fData=new FormData();
                
                for(var key in regObj)
                {
                    fData.append(key,regObj[key]);
                }
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=assignSubjects');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message);
                            getStudents();                          
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }

        });
    });
    function getAssignedSubjects()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getAssignedSubjects');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                if(result.status==1)
                {
                    data=result.data;                    
                }  
            }
        };  
    }
    function getSubjects()
    {
        console.log(data);
        var stsID='msg2';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj1={year1:-1,semester1:-1,department1:-1};
            var status=0;
            for(var key in regObj1)
            {
                var d=getValue(key);
                regObj1[key]=d; 
                console.log(key);
                if(d==-1)
                {
                    console.log(d);
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.getAttribute('placeholder')); 
                    break;
                }
            }
            if(status==0)
            {
                setData(stsID,'');
                var x='<table class="table table-hover"><thead><tr><th>S.No</th><th>Subject Code</th><th>Subject Name</th></tr></thead><tbody>';
                if(data.length>0)
                {
                    var sno=0;
                    for(var i=0;i<data.length;i++)
                    {
                        if(getValue('year1')==data[i].YearIDs && getValue('semester1')==data[i].SemesterIDs && getValue('department1')==data[i].dept_ids)
                        {
                            sno++;
                            x+='<tr><td>'+sno+'</td><td>'+data[i].SubjectCode+'</td><td>'+data[i].SubjectName+'</td></tr>';
                        }
                        
                    }                      
                }                    
                x+='</tbody></table>';
                setData('faculty',x);
            }

    }
    </script>
</head>

<body>
<?php 
include('header-a.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Assign  <span>Subject</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-12">
                        
                        <div class="row mb-2"> <div class="col-lg-2">
                        <a class="btn btn-primary mb-2" href="#myModal" data-toggle="modal">Assign Subject</a>
                </div> <div class="col-lg-2">
                    <select id="year1" class="form-control" placeholder="Select Year"><option value="-1">Select Year</option></select>
                </div> 
                <div class="col-lg-2">
                    <select id="semester1" class="form-control" placeholder="Select Semester"><option value="-1">Select Semester</option></select>
                </div>
                        <div class="col-lg-3">
                            <select id="department1" class="form-control" placeholder="Select Department"><option value="-1">Select Department</option></select>
                            </div>
                            <div class="col-lg-2">
                            <button type="button" class="btn btn-success" onclick="getSubjects()">Get Subjects</button>
                            </div>
                            <div class="col-lg-12" id="msg2">
                            </div>
                        </div>
                        
                        <div class="table-responsive" id="faculty"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>
     <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Assign Subject</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" id="regFm">
                <div class="form-group">
                    <select id="year" class="form-control" placeholder="Select Year"><option value="-1">Select Year</option></select>
                </div> 
                <div class="form-group">
                    <select id="semester" class="form-control" placeholder="Select Semester"><option value="-1">Select Semester</option></select>
                </div>
                <div class="form-group">
                    <select id="department" class="form-control" placeholder="Select Department"><option value="-1">Select Department</option></select>
                </div>
                <div class="form-group">
                    <select id="subject" multiple class="form-control" placeholder="Select atleast 1 Subject"><option value="-1">Select Subjects</option></select>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Assign Subjects</button>
                </div>
                <div class="form-group text-center" id="msg1"></div>
          </form>
        </div> 
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
  
</body>
</html>