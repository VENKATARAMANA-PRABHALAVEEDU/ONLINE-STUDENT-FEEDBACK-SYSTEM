var apiURL='api.php';
var loginObj=getLocalData('login');
var years=[];
var sems=[];
var departments=[];
var subjects=[];
function logout()
{
    localStorage.removeItem('login');
    location.href='index.php';
}
function redirect()
{
    var loginObj=getLocalData('login');
    if(loginObj!=null)
    {
        if(loginObj.user_role_ids==2)
        {
            location.href='admin-home.php';
        }
        else if(loginObj.user_role_ids==3)
        {
            location.href='student-home.php';
        }
        else if(loginObj.user_role_ids==4)
        {
            location.href='faculty-home.php';
        }
    }
}
function showSuccessMessage(id,msg)
{
    $("#"+id).html(msg);
    $("#"+id).removeClass("fail");
    $("#"+id).addClass("success");	
}
function showErrorMessage(id,msg)
{
    $("#"+id).html(msg);
    $("#"+id).removeClass("success");
    $("#"+id).addClass("fail");
    
}
function displayDataTable()
	{
		var obj={
		  paging      : true,
		  lengthChange: true,
		  searching   : true,
		  ordering   : true,
		  info       : true,
		  autoWidth   : true
		};
		  $('#example2').DataTable(obj)
	}
	function getValue(id)
	{
	  return $('#'+id).val();
	}
	function setValue(id,data)
	{
	  $('#'+id).val(data);
	}
	function getIntValue(id)
	{
		return parseInt(document.getElementById(id).value);  
	}
	function setData(id,data)
	{
	  $('#'+id).html(data);
	}
	function getData(id)
	{
	  return $('#'+id).html();
	}
	function handleModal(id,status)
	{
	  if(status==1)
	  {
		$('#'+id).modal('show');
	  }
	  else 
	  {
		$('#'+id).modal('hide');
	  }  
    }
    function ValidateEmail(mail) 
{
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
 if (re.test(mail))
  {
    return true;
  }
  else 
  {
    return false;
  }
    
}

function NumbersOnly(MyField, e, dec)
{	
    var key;			
    var keychar;			
    if (window.event)			   
    key = window.event.keyCode;			
    else if (e)			   
    key = e.which;			
    else			   
    return true;			
    keychar = String.fromCharCode(key);			
    if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )			   return true;			
    else if ((("0123456789").indexOf(keychar) > -1))			   
    return true;			
    else if (dec && (keychar == "."))			   
    {			   
      MyField.form.elements[dec].focus();			   
      return false;			   
    }			
    else			   
    return false;		
}

function converToJson(obj)
{
  return JSON.parse(obj); 
}
function getLocalData(key) 
{
    const obj = localStorage.getItem(key);
    if (obj == null)
    {
      return null;
    }
    else 
    {
      return JSON.parse(obj);
    }
}
function setLocalData(key, data)
{
    localStorage.setItem(key, JSON.stringify(data)); 
}
function getTag(id)
{
    return document.getElementById(id);
}

function getYearsBox(id)
{ 
    if(years.length==0)
    {
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getYears');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                var x='<option value="-1">Select Year</option>';
                if(result.status==1)
                {
                    years=result.data; 
                    for(var i=0;i<years.length;i++)
                    {
                        x+='<option value="'+years[i].YearID+'">'+years[i].YearName+' Year</option>';
                    }                  
                }   
                setData(id,x);   
            }
        };  
    }
}


function getSemestersBox(id)
{ 
    if(sems.length==0)
    {
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getSemesters');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);  
                var x='<option value="-1">Select Semester</option>';
                if(result.status==1)
                {
                    sems=result.data; 
                    for(var i=0;i<sems.length;i++)
                    {
                        x+='<option value="'+sems[i].SemesterID+'">'+sems[i].SemesterName+' Semester</option>';
                    }                  
                }   
                setData(id,x);   
            }
        };  
    }
}
function getDepartmentsBox(id)
{ 
    if(sems.length==0)
    {
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getDepartments');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);  
                var x='<option value="-1">Select Department</option>';
                if(result.status==1)
                {
                    departments=result.data; 
                    for(var i=0;i<departments.length;i++)
                    {
                        x+='<option value="'+departments[i].dept_id+'">'+departments[i].dept_name+'</option>';
                    }                  
                }   
                setData(id,x);   
            }
        };  
    }
}
function getSubjectsBox(id)
    {
        
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getSubjects');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);  
                var x='<option value="-1">Select Subjects</option>';
                if(result.status==1)
                {
                    subjects=result.data; 
                    for(var i=0;i<subjects.length;i++)
                    {
                        x+='<option value="'+subjects[i].SubjectID+'">('+subjects[i].SubjectCode+')'+subjects[i].SubjectName+'</option>';
                    }                  
                }   
                setData(id,x); 
            }
        };
    }