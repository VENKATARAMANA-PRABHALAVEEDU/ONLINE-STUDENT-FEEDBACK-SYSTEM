<?php
$jsonData=array('status' => 0, "message" => "No Data Received");
function connection()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $conn=null;
    
    try 
    {
        $conn = new PDO("mysql:host=$servername;dbname=vyrsoga1_feedback", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $jsonData['message']="Connected successfully";
    }
    catch(PDOException $e)
    {
        $jsonData['message']="Database Connection failed: " . $e->getMessage();
    }
    return $conn;
}
function sendJSON($jsonData)
{
    header("Content-Type:application/json");
    echo json_encode($jsonData,JSON_PRETTY_PRINT);
}
function selectQuery($sql,$params=array())
{
    $output=array();
    $conn=connection();
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);                
    $count = $stmt->rowCount();
    if($count>0)
    {
        while($result = $stmt->fetch(PDO::FETCH_ASSOC))
        {
            array_push($output,$result);
        } 
    }
    return $output;
}
function insertUpdateDeleteQuery($sql,$params=array())
{
    $conn=connection();
    $stmt = $conn->prepare($sql);
    try{
        return $stmt->execute($params);
    }
    catch(PDOException $e)
    {
        return false;
    }
    
}
?>