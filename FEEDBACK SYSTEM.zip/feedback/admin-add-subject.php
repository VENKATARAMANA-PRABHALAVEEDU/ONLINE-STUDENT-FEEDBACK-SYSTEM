<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Admin add subjects</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
        var data=[];
    $(function(){
        getSubjects();
       
        $("#regFm").on('submit',function(e){
            e.preventDefault();
            var stsID='msg1';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj={SubjectCode:'',SubjectName:''};
            var status=0;
            for(var key in regObj)
            {
                var d=getValue(key);
                if(d.trim().length==0)
                {
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.placeholder); 
                    break;
                }
                else 
                {
                    regObj[key]=d; 
                }
            }
            if(status==0)
            {
                var fData=new FormData();
                
                for(var key in regObj)
                {
                    fData.append(key,regObj[key]);
                }
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=addSubject');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message);
                            getSubjects();                            
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }

        });
    });
    function getSubjects()
    {
        
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getSubjects');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var x='<table class="table table-hover"><thead><tr><th>S.No</th><th>Subject Code</th><th>Subject Name</th></tr></thead><tbody>';
                var result=converToJson(http.responseText);
                console.log(result);
                if(result.status==1)
                {
                    data=result.data;
                    var sno=0;
                    for(var i=0;i<data.length;i++)
                    {
                        sno++;
                        x+='<tr><td>'+sno+'</td><td>'+data[i].SubjectCode+'</td><td>'+data[i].SubjectName+'</td></tr>';
                    }                      
                }                    
                x+='</tbody></table>';
                setData('faculty',x);
            }
        };
    }
    </script>
</head>

<body>
<?php 
include('header-a.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Add <span>Subject</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-12">
                        <a class="btn btn-primary mb-2" href="#myModal" data-toggle="modal">Add Subject</a>
                        <div class="table-responsive" id="faculty"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>
     <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Subject</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" id="regFm">
                <div class="form-group">
                    <input type="text" id="SubjectCode" class="form-control" placeholder="Enter Subject Code" />
                </div>                
                <div class="form-group">
                    <input type="text" id="SubjectName" class="form-control" placeholder="Enter Subject Name" />
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Add Subject</button>
                </div>
                <div class="form-group text-center" id="msg1"></div>
          </form>
        </div> 
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
  
</body>
</html>