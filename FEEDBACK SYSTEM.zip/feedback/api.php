<?php 
include('functions.php');
$isSegment=0;
$segment='';
if(count($_GET)>0)
{
    if(isset($_GET['segment']))
    {
        $isSegment=1;  
        $segment=$_GET['segment'];
    }

}
if($isSegment==1)
{
    if(strlen($segment)>0)
    {
        if($segment=="login")
        {
            if(count($_POST)>0)
            {
                $email=$_POST['email'];
                $pwd=$_POST['password'];
                $pwd1=md5($pwd);
                $conn=connection();
                $stmt = $conn->prepare("select * from users where user_email=? and user_password=?");
                $stmt->execute(array($email, $pwd1));                
                $count = $stmt->rowCount();
                if($count>0)
                {
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $jsonData['status']=1;  
                    $jsonData['message']="Login successful. Please wait, we are redirecting you to next level"; 
                    $jsonData['data']= $result;  
                }else 
                {
                    $jsonData['message']="Invalid Email/Password";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }         
        else if($segment=="addFeedback")
        {
            if(count($_POST)>0)
            {
                $myData= json_decode($_POST['ids']); 
                $faculty=$_POST['faculty'];
                $student=$_POST['student'];
                foreach($myData as $m)
                {
                    $sql="insert into feedback(student_id,faculty_id,question_id,marks_id) values(?,?,?,?)";
                    $result=insertUpdateDeleteQuery($sql,array($student,$faculty,$m->id,$m->opt));                
                    if($result)
                    {
                    } 
                }
                $jsonData['status']=1;  
                $jsonData['message']="Feedback sent successfully"; 
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }
               
        else if($segment=="showGraph")
        {
            if(count($_GET)>0)
            {
                $faculty=$_GET['faculty'];
                $sql1="select question_id as label, avg(marks_id) as y from feedback where faculty_id=? GROUP BY question_id";
                $result1=selectQuery($sql1,array($faculty));                
                $jsonData['status']=1;  
                $jsonData['data']=$result1; 
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }
        else if($segment=="addStudent")
        {
            if(count($_POST)>0)
            {
                $jsonData['data1']= $_POST; 
                $firstName=$_POST['firstName'];
                $lastName=$_POST['lastName'];
                $userEmail=$_POST['userEmail'];
                $year=$_POST['year'];
                $semester=$_POST['semester'];
                $department=$_POST['department'];
                
                $userPwd=$_POST['userPwd'];
                $pwd1=md5($userPwd);
                $sql="insert into users(user_role_ids,user_first_name,user_last_name,user_email,user_password,user_year,user_sem,user_dept_ids) values(?,?,?,?,?,?,?,?)";
                $result=insertUpdateDeleteQuery($sql,array(3,$firstName,$lastName,$userEmail, $pwd1,$year, $semester,$department));                
                if($result)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']="Student Added successfully"; 
                    $jsonData['data']= $result;  
                }
                else 
                {
                    $jsonData['message']="Email already existed";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }
        else if($segment=="changePassword")
        {
            if(count($_POST)>0)
            {
                $id=$_POST['userID'];               
                $userPwd=$_POST['userPwd'];
                $pwd1=md5($userPwd);
                $sql="update users set user_password=? where user_id=?";
                $result=insertUpdateDeleteQuery($sql,array($pwd1,$id));   
                if($result)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']="Password changed successfully"; 
                    $jsonData['data']= $result;  
                }
                else 
                {
                    $jsonData['message']="Updated";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }
        
        else if($segment=="assignFaculty")
        {
            if(count($_POST)>0)
            {
                $subject=$_POST['subject'];
                $facultyID=$_POST['facultyID'];
                $department=$_POST['department'];
                $year=$_POST['year'];
                $semester=$_POST['semester'];
                $sql="insert into assign_faculty(YearIDs,SemesterIDs,dept_ids,SubjectIDs,user_ids) values(?,?,?,?,?)";
                $result=insertUpdateDeleteQuery($sql,array($year,$semester,$department, $subject,$facultyID));               
                if($result)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']="Faculty Assigned successfully"; 
                    $jsonData['data']= $result;  
                }
                else 
                {
                    $jsonData['message']="Faculty already assigned";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        }
        else if($segment=="assignSubjects")
        {
            if(count($_POST)>0)
            {
                $subjects=explode(',',$_POST['subject']);
                $department=$_POST['department'];
                $year=$_POST['year'];
                $semester=$_POST['semester'];
                $j=0;
                if(count($subjects)>0)
                {
                   foreach($subjects as $subject)
                   {
                        $sql="insert into dept_subject(YearIDs,SemesterIDs,dept_ids,SubjectIDs) values(?,?,?,?)";
                        $result=insertUpdateDeleteQuery($sql,array($year,$semester,$department, $subject));                
                        if($result)
                        {
                            $j++;
                        }
                   } 
                }              
                if($j>0)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']=$j." Subjects Added successfully"; 
                }
                else 
                {
                    $jsonData['message']="Subjects Already Assigned";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        } 
        else if($segment=="addSubject")
        {
            if(count($_POST)>0)
            {
                $jsonData['data1']= $_POST; 
                $SubjectName=$_POST['SubjectName'];
                $SubjectCode=$_POST['SubjectCode'];
                $sql="insert into subjects(SubjectName,SubjectCode) values(?,?)";
                $result=insertUpdateDeleteQuery($sql,array($SubjectName,$SubjectCode));                
                if($result)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']="Subject Added successfully"; 
                    $jsonData['data']= $result;  
                }
                else 
                {
                    $jsonData['message']="Subject already existed";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        } 
        else if($segment=="addFaculty")
        {
            if(count($_POST)>0)
            {
                $jsonData['data1']= $_POST; 
                $firstName=$_POST['firstName'];
                $lastName=$_POST['lastName'];
                $userEmail=$_POST['userEmail'];
                $userPwd=$_POST['userPwd'];
                $pwd1=md5($userPwd);
                $sql="insert into users(user_role_ids,user_first_name,user_last_name,user_email,user_password) values(?,?,?,?,?)";
                $result=insertUpdateDeleteQuery($sql,array(4,$firstName,$lastName,$userEmail, $pwd1));                
                if($result)
                {
                    $jsonData['status']=1;  
                    $jsonData['message']="Faculty Added successfully"; 
                    $jsonData['data']= $result;  
                }
                else 
                {
                    $jsonData['message']="Email already existed";  
                }
            }
            else 
            {
                $jsonData['message']="No Data received";  
            }
        } 
        else if($segment=='getAssignedSubjects')
        {
            $sql="select * from dept_subject ds left join years y on y.YearID=ds.YearIDs left join semesters s on ds.SemesterIDs=s.SemesterID left join departments d on ds.dept_ids=d.dept_id left join  subjects sb on ds.SubjectIDs=sb.SubjectID";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
        }          
        else if($segment=='getQuestions')
        {
            $sql="select * from category order by category_id";
            $result=selectQuery($sql);
            $data1=array();
            if(count($result)>0)
            {

                foreach($result as $row)
                {
                    $sql1="select * from sub_categories where category_ids=".$row['category_id'];
                    $result2=selectQuery($sql1);
                    array_push($data1,array("cid" => $row['category_id'], 'd' => $row, 's' => $result2 ));
                }
                $jsonData['status']=1; 
                $jsonData['data']=$data1; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
        }        
        else if($segment=='getAssignedFaculty')
        {
            $sql="select * from assign_faculty ds left join years y on y.YearID=ds.YearIDs left join semesters s on ds.SemesterIDs=s.SemesterID left join departments d on ds.dept_ids=d.dept_id left join  subjects sb on ds.SubjectIDs=sb.SubjectID left join users u on ds.user_ids=u.user_id";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
        }
        else if($segment=='getSubjects')
        {
            $sql="select * from subjects";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
        }
        else if($segment=='getFaculty')
        {
            $sql="select * from users where user_role_ids=4";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
        }
        else if($segment=='getStudents')
        {
            $sql="select * from users u left join years y on user_year=YearID left join semesters s ON user_sem=SemesterID left join departments d on u.user_dept_ids=d.dept_id where user_role_ids=3";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            }
             
        }
        else if($segment=='getYears')
        {
            $sql="select * from years";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            } 
        }
        else if($segment=='getSemesters')
        {
            $sql="select * from semesters";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            } 
        }
        
        else if($segment=='getDepartments')
        {
            $sql="select * from departments";
            $result=selectQuery($sql);
            if(count($result)>0)
            {
                $jsonData['status']=1; 
                $jsonData['data']=$result; 
                $jsonData['message']="Data found"; 
            }
            else 
            {
                $jsonData['message']="No Data found"; 
            } 
        }
        else 
        {
            $jsonData['message']="No segment Found 3";  
        }
    }
    else 
    {
        $jsonData['message']="No segment Found 2";  
    }
}
else 
{
    $jsonData['message']="No segment Found 1";  
}

sendJSON($jsonData);
?>