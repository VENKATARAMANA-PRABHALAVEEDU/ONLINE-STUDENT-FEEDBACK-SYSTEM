<script>
$(function(){
    if(loginObj!=null)
    {
        redirect();
    }
    $("#loginFm").on('submit',function(e) {
        e.preventDefault();
        var email=getValue('userEmail');
        var pwd=getValue('userPwd');
        var stsID='msg1';
        showErrorMessage(stsID,'Please wait...'); 
        if(email.trim().length==0)
        {
            showErrorMessage(stsID,'Please enter Email ID');
        }    
        else if(ValidateEmail(email)==false)
        {
            showErrorMessage(stsID,'Please enter valid Email ID');
        }
        else if(pwd.trim().length==0)
        {
            showErrorMessage(stsID,'Please enter Password');
        }
        else 
        {
            var fData=new FormData();
            fData.append('email',email);
            fData.append('password',pwd);
            var http=new XMLHttpRequest();
            http.open('POST',apiURL+'?segment=login');
            http.send(fData);
            http.onreadystatechange=function()
            {
                if(http.readyState==4 && http.status==200)
                {
                    var result=converToJson(http.responseText);
                    console.log(result);
                    if(result.status==1)
                    {
                        showSuccessMessage(stsID,result.message);
                        setLocalData('login',result.data);
                        redirect();
                        
                    }
                    else 
                    {
                        showErrorMessage(stsID,result.message); 
                    }
                }
            };
        }
    });
});
</script>
<header>
            <nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary pt-3">
               <h1><a class="navbar-brand" href="index.php">Feedback
							<span>System</span>
						</a></h1>

                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
								<li class="nav-item active">
									<a class="nav-link" href="index.php">Home
										<span class="sr-only">(current)</span>
									</a>
								</li>
								<li class="nav-item mx-xl-4 mx-lg-3 my-lg-0 my-3">
									<a class="nav-link" href="#myModal" data-toggle="modal">Login@</a>
								</li>
							<!--	<li class="nav-item mx-xl-4 mx-lg-3 my-lg-0 my-3">
									<a class="nav-link" href="about.php">About Us</a>
								</li>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
									    aria-expanded="false">
										Dropdown
									</a>
									<div class="dropdown-menu" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="services.php">Services</a>
										<a class="dropdown-item" href="typo.php">Typography</a>
										<div class="dropdown-divider"></div>
										<a class="dropdown-item" href="gallery.php">Gallery</a>
										
									</div>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="contact.php">Contact Us</a>
								</li>-->
					</ul>
				</div>
			</nav>
        </header>
  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Login</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form method="post" id="loginFm">
                <div class="form-group">
                    <input type="email" id="userEmail" class="form-control" placeholder="Enter Email ID" />
                </div>
                <div class="form-group">
                    <input type="password" id="userPwd" class="form-control" placeholder="Enter Password" />
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Login</button>
                </div>
                <div class="form-group text-center" id="msg1"></div>
          </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
        </div>
        
      </div>
    </div>
  </div>
  