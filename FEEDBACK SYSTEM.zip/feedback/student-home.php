<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Admin Home</title>
    <?php 
	    include('header-scripts.php');
	?>
</head>

<body>
<?php 
include('header-s.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Dash  <span>board</span></h3>
			<div class="inner_sec_info_wthree_agile mt-md-5 pt-3">
				<div class="row help_full">
					<div class="col-lg-6 banner_bottom_grid help">
						<img src="images/g1.jpg" alt=" " class="img-fluid">
					</div>
					<div class="col-lg-6 banner_bottom_left1">
						<h4>MeRITS STUDENTS</h4>
						<p>Pellentesque convallis diam consequat magna vulputate malesuada. Cras a ornare elit. Nulla viverra pharetra sem, eget
							pulvinar neque pharetra ac.</p>
						<p>Lorem Ipsum convallis diam consequat magna vulputate malesuada. Cras a ornare elit. Nulla viverra pharetra sem, eget
							pulvinar neque pharetra ac.Nullal condimentum interdum vel eget enim. Curabitur mattis orci sed le. Nullal condimentum interdum vel eget enim. Curabitur mattis orci sed le. MeRITS</p>
						</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>
</body>
</html>