-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2019 at 03:47 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vyrsoga1_feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign_faculty`
--

CREATE TABLE `assign_faculty` (
  `assign_id` int(11) NOT NULL,
  `YearIDs` int(1) NOT NULL,
  `SemesterIDs` int(1) NOT NULL,
  `dept_ids` varchar(10) NOT NULL,
  `SubjectIDs` int(11) NOT NULL,
  `user_ids` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_faculty`
--

INSERT INTO `assign_faculty` (`assign_id`, `YearIDs`, `SemesterIDs`, `dept_ids`, `SubjectIDs`, `user_ids`) VALUES
(1, 2, 2, '01', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(3, 'Class Assessment'),
(2, 'Class Teaching'),
(1, 'Course Material');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `dept_id` varchar(10) NOT NULL,
  `dept_name` varchar(300) NOT NULL,
  `dept_active` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`dept_id`, `dept_name`, `dept_active`) VALUES
('01', 'Civil Engineering', 1),
('02', 'Electrical & Electronics Engineering', 1),
('03', 'Mechanical Engineering', 1),
('04', 'Electronics & Communication Engineering', 1),
('05', 'Computer Science & Engineering', 1),
('12', 'Information Technology', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dept_subject`
--

CREATE TABLE `dept_subject` (
  `YearIDs` int(1) NOT NULL,
  `SemesterIDs` int(1) NOT NULL,
  `dept_ids` varchar(10) NOT NULL,
  `SubjectIDs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept_subject`
--

INSERT INTO `dept_subject` (`YearIDs`, `SemesterIDs`, `dept_ids`, `SubjectIDs`) VALUES
(2, 2, '01', 2),
(2, 2, '01', 4),
(2, 2, '01', 5);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `marks_id` int(11) NOT NULL
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `student_id`, `faculty_id`, `question_id`, `marks_id`) VALUES
(1, 9, 2, 6, 3),
(2, 9, 2, 4, 3),
(9, 9, 2, 3, 3),
(10, 9, 2, 2, 3),
(11, 9, 2, 1, 3),
(12, 9, 2, 10, 3),
(13, 9, 2, 9, 3),
(15, 9, 2, 5, 3),
(16, 9, 2, 8, 3),
(18, 9, 2, 7, 3),
(19, 9, 2, 12, 3),
(20, 9, 2, 11, 3),
(21, 10, 2, 3, 5),
(22, 10, 2, 2, 1),
(23, 10, 2, 1, 3),
(24, 10, 2, 10, 2),
(25, 10, 2, 9, 3),
(26, 10, 2, 6, 1),
(27, 10, 2, 5, 3),
(28, 10, 2, 8, 2),
(29, 10, 2, 4, 5),
(30, 10, 2, 7, 1),
(31, 10, 2, 12, 1),
(32, 10, 2, 11, 2);

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

CREATE TABLE `semesters` (
  `SemesterID` int(1) NOT NULL,
  `SemesterName` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`SemesterID`, `SemesterName`) VALUES
(1, 'I'),
(2, 'II'),
(3, 'III'),
(4, 'IV');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SubjectID` int(11) NOT NULL,
  `SubjectCode` varchar(20) NOT NULL,
  `SubjectName` varchar(300) NOT NULL,
  `SubjectStatus` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`SubjectID`, `SubjectCode`, `SubjectName`, `SubjectStatus`) VALUES
(1, 'M1', 'M1', 1),
(2, 'M2', 'M2', 1),
(3, 'M3', 'M3', 1),
(4, 'PHY', 'PHYSICS', 1),
(5, 'MECH', 'MECHANICS', 1),
(6, 'VLSI', 'VLSI', 1),
(7, 'C', 'C', 1),
(8, 'JAVA', 'JAVA', 1),
(9, 'OR', 'ORACLE', 1),
(10, 'DB', 'DBMS', 1),
(11, 'gfvv', 'vbxcvb', 1),
(13, 'fgdfg', 'gfgsdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `sub_category_id` int(11) NOT NULL,
  `category_ids` int(11) NOT NULL,
  `sub_category_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`sub_category_id`, `category_ids`, `sub_category_name`) VALUES
(3, 1, 'Course integrates throretical course concepts with the real world examples:'),
(2, 1, 'Course objectives,learning outcomes and grading criteria are clear to me:'),
(1, 1, 'Teacher provided the course outline having weekly content plan with list of required text book:'),
(10, 2, 'Teacher has competed the whole course as per course outline:'),
(9, 2, 'Teacher is available and helpful during counseling hours:'),
(6, 2, 'Teacher is good at explaining the subject matter:'),
(5, 2, 'Teacher is good at stimulating the interest in the course content:'),
(8, 2, 'Teacher is good at using innovative teaching methods/ways:'),
(4, 2, 'Teacher is punctual,arrives on time and leaves on time:'),
(7, 2, 'Teacher''s presentation was clear,loud ad easy to understand:'),
(12, 3, 'Assessments conducted are clearly connected to maximize learining objectives:'),
(11, 3, 'Teacher was always fair and impartial:');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_role_ids` int(11) NOT NULL,
  `user_year` int(11) NOT NULL DEFAULT '0',
  `user_sem` int(11) NOT NULL DEFAULT '0',
  `user_dept_ids` varchar(10) DEFAULT NULL,
  `user_first_name` varchar(250) NOT NULL,
  `user_last_name` varchar(250) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_mobile` varchar(10) DEFAULT NULL,
  `user_password` text NOT NULL,
  `user_status` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_role_ids`, `user_year`, `user_sem`, `user_dept_ids`, `user_first_name`, `user_last_name`, `user_email`, `user_mobile`, `user_password`, `user_status`) VALUES
(1, 2, 0, 0, NULL, 'Admin', 'Admin', 'admin@gmail.com', NULL, '21232f297a57a5a743894a0e4a801fc3', 1),
(2, 4, 0, 0, NULL, 'Faculty', 'Faculty', 'faculty@gmail.com', NULL, '21232f297a57a5a743894a0e4a801fc3', 1),
(4, 4, 0, 0, NULL, 'Faculty2', 'Faculty2', 'Faculty2@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', 1),
(5, 4, 0, 0, NULL, 'Faculty2', 'Faculty2', 'Faculty3@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', 1),
(6, 4, 0, 0, NULL, 'Faculty3', 'Faculty3', 'Faculty33@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', 1),
(10, 3, 2, 2, '01', 'student2', 'student2', 'student2@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', 1),
(9, 3, 2, 2, '01', 'ghghgf', 'gfhgfjhgf', 'hello1@gmail.com', NULL, '202cb962ac59075b964b07152d234b70', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_role_id` int(11) NOT NULL,
  `user_role_name` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_role_id`, `user_role_name`) VALUES
(2, 'Admin'),
(3, 'Student'),
(4, 'Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `YearID` int(1) NOT NULL,
  `YearName` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `years`
--

INSERT INTO `years` (`YearID`, `YearName`) VALUES
(1, 'I'),
(2, 'II'),
(3, 'III'),
(4, 'IV');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assign_faculty`
--
ALTER TABLE `assign_faculty`
  ADD PRIMARY KEY (`assign_id`),
  ADD UNIQUE KEY `YearIDs` (`YearIDs`,`SemesterIDs`,`dept_ids`,`SubjectIDs`,`user_ids`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `dept_subject`
--
ALTER TABLE `dept_subject`
  ADD PRIMARY KEY (`YearIDs`,`SemesterIDs`,`dept_ids`,`SubjectIDs`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD UNIQUE KEY `student_id` (`student_id`,`faculty_id`,`question_id`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`SemesterID`),
  ADD UNIQUE KEY `SemesterName` (`SemesterName`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SubjectID`),
  ADD UNIQUE KEY `SubjectCode` (`SubjectCode`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`sub_category_id`),
  ADD UNIQUE KEY `category_ids` (`category_ids`,`sub_category_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD KEY `user_role_ids` (`user_role_ids`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_role_id`),
  ADD UNIQUE KEY `user_role_name` (`user_role_name`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`YearID`),
  ADD UNIQUE KEY `YearName` (`YearName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assign_faculty`
--
ALTER TABLE `assign_faculty`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `sub_categories_ibfk_1` FOREIGN KEY (`category_ids`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
