<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>stu give feedback</title>
    <?php 
	    include('header-scripts.php');
    ?>
    <script>
        var data=[];
        var data2=[];
    $(function(){
        getQuestions();
        getAssignedFaculty();
        $("#regFm").on('submit',function(e){
            e.preventDefault();
            var stsID='msg1';
            showErrorMessage(stsID,'Please wait...'); 
            var regObj={SubjectCode:'',SubjectName:''};
            var status=0;
            for(var key in regObj)
            {
                var d=getValue(key);
                if(d.trim().length==0)
                {
                    status=1;
                    var tag=getTag(key);
                    showErrorMessage(stsID,tag.placeholder); 
                    break;
                }
                else 
                {
                    regObj[key]=d; 
                }
            }
            if(status==0)
            {
                var fData=new FormData();
                
                for(var key in regObj)
                {
                    fData.append(key,regObj[key]);
                }
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=addSubject');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message);
                            getSubjects();                            
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }

        });
    });
    function getQuestions()
    {
        
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getQuestions');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var x='';
                var result=converToJson(http.responseText);
                console.log(result);
                if(result.status==1)
                {
                    var dat=result.data;
                    var sno=0;
                    for(var i=0;i<dat.length;i++)
                    {
                        sno++;
                        x+='<div class="row"><div class="col-md-12 mb-2 pb-2">'+sno+'. '+dat[i].d.category_name;
                        if(dat[i].s.length>0)
                        {
                            var sno1=0;
                            for(var j=0;j<dat[i].s.length;j++)
                            {
                                sno1++;
                                x+='<div class="row mt-2 px-3"><div class="col-md-8 pl-3">Q'+sno1+'. '+dat[i].s[j].sub_category_name+'</div><div class="col-md-4"><input type="hidden" name="qs[]" value="'+dat[i].s[j].sub_category_id+'"/><input type="radio" name="q_'+dat[i].s[j].sub_category_id+'" value="5"/>5<input type="radio" value="4"  name="q_'+dat[i].s[j].sub_category_id+'"/>4<input type="radio" value="3"  name="q_'+dat[i].s[j].sub_category_id+'"/>3<input type="radio" value="2"  name="q_'+dat[i].s[j].sub_category_id+'"/>2<input type="radio" value="1"  name="q_'+dat[i].s[j].sub_category_id+'"/>1</div></div>';
                            }
                        }
                        x+='</div></div>';
                    }   
                    x+='<div class="row"><div class="col-md-12 text-center"><button type="button" class="btn btn-success" onclick="sendFeedback()">Submit Feedback</button></div><div class="col-md-12 text-center" id="msg1"></div></div>';                   
                }                    
                x+='';
                setData('faculty',x);
            }
        };
    }
    function getAssignedFaculty()
    { 
        var http=new XMLHttpRequest();
        http.open('GET',apiURL+'?segment=getAssignedFaculty');
        http.send();
        http.onreadystatechange=function()
        {
            if(http.readyState==4 && http.status==200)
            {
                var result=converToJson(http.responseText);
                var x='<option value="-1">Select subject</option>';
                if(result.status==1)
                {
                    data2=result.data;   
                    console.log(data2);
                    console.log(loginObj);  
                    for(var i=0;i<data2.length;i++)
                    {
                        if(loginObj.user_year==data2[i].YearIDs && loginObj.user_sem==data2[i].SemesterIDs && loginObj.user_dept_ids==data2[i].dept_ids)
                        {
                            x+='<option value="'+data2[i].user_id+'">'+data2[i].user_first_name+' '+data2[i].user_last_name+'('+data2[i].user_email+')</option>';
                        }
                    }                
                }  
                setData('facultyIDs',x);
            }
        };  
    }
    function sendFeedback()
    {
        var f=getValue('facultyIDs');
        var stsID="msg1";
        if(f==-1)
        {
            showErrorMessage(stsID,'Please select faculty'); 
        }
        else 
        {
            var x=$("input[name='qs[]']");
            var ids={d:[]};
            for(var i=0;i<x.length;i++)
            {
                var y=$("input[name='q_"+x[i].value+"']");
                for(var j=0;j<y.length;j++)
                {
                    console.log(y[j].checked); 
                    console.log(y[j].value); 
                    if(y[j].checked==true)
                    {
                        ids.d.push({id:x[i].value,opt:y[j].value});
                    }
                }
            }
            console.log(ids);
            if(ids.d.length>0)
            {
                var fData=new FormData();                
                fData.append('faculty',f);
                fData.append('student',loginObj.user_id);
                fData.append('ids',JSON.stringify(ids.d));
                var http=new XMLHttpRequest();
                http.open('POST',apiURL+'?segment=addFeedback');
                http.send(fData);
                http.onreadystatechange=function()
                {
                    if(http.readyState==4 && http.status==200)
                    {
                        var result=converToJson(http.responseText);
                        console.log(result);
                        if(result.status==1)
                        {
                            showSuccessMessage(stsID,result.message); 
                        }
                        else 
                        {
                            showErrorMessage(stsID,result.message); 
                        }
                    }
                };
            }
            else 
            {
                showErrorMessage(stsID,'Please give feedback');  
            }            
        }
    }
    </script>
</head>

<body>
<?php 
include('header-s.php');
?>
	 <!-- //banner-text -->
	 <section class="banner_bottom1 py-md-5">
		<div class="container py-4 mt-2">
        <h3 class="heading-agileinfo text-center">Give <span>Feedback!!</span></h3>
			<div class="inner_sec_info_wthree_agile pt-3">
				<div class="row help_full">
					<div class="col-lg-12">
                    <div class="row mb-2"> <div class="col-lg-6">
                    <select id="facultyIDs" class="form-control" placeholder="Select subject"><option value="-1">Select subject</option></select>
                </div> 
                            <div class="col-lg-12" id="msg2">
                            </div>
                        </div>
                        <div id="faculty"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <script src="js/bootstrap.js"></script>

</body>
</html>